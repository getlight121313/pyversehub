import type { MDXComponents } from 'mdx/types';
import CodeBlock from '@/app/components/CodeBlock';

export function useMDXComponents(components: MDXComponents): MDXComponents {
  return {
    CodeBlock,
    ...components,
  };
}
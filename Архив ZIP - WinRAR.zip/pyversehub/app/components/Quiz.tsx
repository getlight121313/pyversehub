'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';

interface Question {
  question: string;
  options: string[];
  correct: number;
  explanation: string;
}

interface QuizProps {
  questions: Question[];
}

export default function Quiz({ questions }: QuizProps) {
  const [current, setCurrent] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [finished, setFinished] = useState(false);

  const question = questions[current];

  const handleSelect = (index: number) => {
    if (showResult) return;
    setSelected(index);
  };

  const checkAnswer = () => {
    if (selected === null) return;
    setShowResult(true);
    if (selected === question.correct) {
      setScore(score + 1);
    }
  };

  const nextQuestion = () => {
    if (current + 1 < questions.length) {
      setCurrent(current + 1);
      setSelected(null);
      setShowResult(false);
    } else {
      setFinished(true);
    }
  };

  const reset = () => {
    setCurrent(0);
    setSelected(null);
    setShowResult(false);
    setScore(0);
    setFinished(false);
  };

  if (finished) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="bg-white dark:bg-[#161B22] p-6 rounded-lg shadow-md"
      >
        <h3 className="text-2xl font-bold mb-4">Результат</h3>
        <p className="text-lg">Вы ответили правильно на {score} из {questions.length} вопросов.</p>
        <button
          onClick={reset}
          className="mt-4 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        >
          Пройти заново
        </button>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="bg-white dark:bg-[#161B22] p-6 rounded-lg shadow-md"
    >
      <h3 className="text-xl font-semibold mb-2">Вопрос {current + 1} из {questions.length}</h3>
      <p className="mb-4 text-lg">{question.question}</p>
      <div className="space-y-3">
        {question.options.map((opt, idx) => (
          <div
            key={idx}
            className={`p-3 border rounded-lg cursor-pointer transition-colors ${
              selected === idx
                ? showResult
                  ? idx === question.correct
                    ? 'bg-green-100 dark:bg-green-900 border-green-500'
                    : 'bg-red-100 dark:bg-red-900 border-red-500'
                  : 'bg-blue-100 dark:bg-blue-900 border-blue-500'
                : 'border-gray-300 dark:border-gray-700 hover:bg-gray-100 dark:hover:bg-gray-800'
            }`}
            onClick={() => handleSelect(idx)}
          >
            {opt}
          </div>
        ))}
      </div>
      {!showResult ? (
        <button
          onClick={checkAnswer}
          disabled={selected === null}
          className="mt-4 px-4 py-2 bg-blue-600 text-white rounded disabled:opacity-50 disabled:cursor-not-allowed hover:bg-blue-700"
        >
          Проверить
        </button>
      ) : (
        <div className="mt-4">
          <p className="mb-2 text-gray-700 dark:text-gray-300">{question.explanation}</p>
          <button
            onClick={nextQuestion}
            className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
          >
            {current + 1 === questions.length ? 'Завершить' : 'Следующий вопрос'}
          </button>
        </div>
      )}
    </motion.div>
  );
}
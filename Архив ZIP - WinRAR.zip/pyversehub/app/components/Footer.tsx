export default function Footer() {
  return (
    <footer className="border-t border-gray-200 dark:border-gray-800 py-6 mt-12">
      <div className="container mx-auto px-4 text-center text-gray-600 dark:text-gray-400">
        © 2026 PyVerseHub. Сделано для предзащиты.
      </div>
    </footer>
  );
}
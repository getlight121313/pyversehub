'use client';

import Link from 'next/link';
import { motion } from 'framer-motion';

interface LessonCardProps {
  title: string;
  description: string;
  slug: string;
  index: number;
}

export default function LessonCard({ title, description, slug, index }: LessonCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
      whileHover={{ scale: 1.02 }}
      className="bg-white dark:bg-[#161B22] rounded-lg shadow-md overflow-hidden border border-gray-200 dark:border-gray-800"
    >
      <Link href={`/course/${slug}`}>
        <div className="p-6">
          <h3 className="text-xl font-semibold mb-2">{title}</h3>
          <p className="text-gray-600 dark:text-gray-400">{description}</p>
        </div>
      </Link>
    </motion.div>
  );
}
'use client';

import Link from 'next/link';
import { useTheme } from 'next-themes';
import { useEffect, useState } from 'react';

export default function Header() {
  const [mounted, setMounted] = useState(false);
  const { theme, setTheme } = useTheme();

  useEffect(() => setMounted(true), []);

  if (!mounted) return null;

  return (
    <header className="border-b border-gray-200 dark:border-gray-800 py-4">
      <div className="container mx-auto px-4 flex justify-between items-center">
        <Link href="/" className="text-2xl font-bold text-blue-600 dark:text-blue-400">
          PyVerseHub
        </Link>
        <nav className="space-x-6">
          <Link href="/" className="hover:text-blue-600 dark:hover:text-blue-400">Главная</Link>
          <Link href="/course" className="hover:text-blue-600 dark:hover:text-blue-400">Курс</Link>
          <Link href="/tests" className="hover:text-blue-600 dark:hover:text-blue-400">Тесты</Link>
        </nav>
        <button
          onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
          className="p-2 rounded-lg bg-gray-200 dark:bg-gray-800"
        >
          {theme === 'dark' ? '🌞' : '🌙'}
        </button>
      </div>
    </header>
  );
}
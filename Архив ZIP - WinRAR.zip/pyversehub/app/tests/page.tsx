import Quiz from '@/app/components/Quiz';

const testQuestions = [
  {
    question: 'Что выведет код: print(2 ** 3)?',
    options: ['6', '8', '9', 'Ошибка'],
    correct: 1,
    explanation: 'Оператор ** возводит в степень: 2^3 = 8.'
  },
  {
    question: 'Какой метод используется для добавления элемента в список?',
    options: ['add()', 'append()', 'push()', 'insert()'],
    correct: 1,
    explanation: 'append() добавляет элемент в конец списка.'
  },
  // Вы можете добавить ещё вопросы по желанию
];

export default function TestsPage() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Тесты по Python</h1>
      <Quiz questions={testQuestions} />
    </div>
  );
}
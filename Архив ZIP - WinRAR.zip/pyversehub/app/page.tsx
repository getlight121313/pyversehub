import Link from 'next/link';
import LessonCard from '@/app/components/LessonCard';

const lessons = [
  { slug: 'variables', title: 'Переменные и типы данных', description: 'Изучите основы переменных в Python.' },
  { slug: 'conditions', title: 'Условные операторы', description: 'if, elif, else на примерах.' },
  { slug: 'loops', title: 'Циклы for и while', description: 'Как повторять действия эффективно.' },
  { slug: 'functions', title: 'Функции', description: 'Определение и вызов функций.' },
  { slug: 'lists', title: 'Списки', description: 'Работа со списками: индексы, методы.' },
  { slug: 'dicts', title: 'Словари', description: 'Хранение данных в парах ключ-значение.' },
];

export default function Home() {
  return (
    <div>
      <h1 className="text-4xl font-bold mb-4 text-center">Изучайте Python легко</h1>
      <p className="text-lg text-center text-gray-600 dark:text-gray-400 mb-8">
        Подробные разборы кода, интерактивные тесты и тёмная тема для комфортного обучения.
      </p>

      <h2 className="text-2xl font-semibold mb-4">Последние уроки</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {lessons.slice(0, 3).map((lesson, idx) => (
          <LessonCard key={lesson.slug} {...lesson} index={idx} />
        ))}
      </div>
      <div className="text-center mt-8">
        <Link href="/course" className="text-blue-600 dark:text-blue-400 hover:underline">
          Смотреть все уроки →
        </Link>
      </div>
    </div>
  );
}
import LessonCard from '@/app/components/LessonCard';

const lessons = [
  { slug: 'variables', title: 'Переменные и типы данных', description: 'Числа, строки, списки...' },
  { slug: 'conditions', title: 'Условные операторы', description: 'if, elif, else' },
  { slug: 'loops', title: 'Циклы', description: 'for, while' },
  { slug: 'functions', title: 'Функции', description: 'def, аргументы, return' },
  { slug: 'lists', title: 'Списки', description: 'list, методы, срезы' },
  { slug: 'dicts', title: 'Словари', description: 'dict, ключи, значения' },
];

export default function CoursePage() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Полный курс Python</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {lessons.map((lesson, idx) => (
          <LessonCard key={lesson.slug} {...lesson} index={idx} />
        ))}
      </div>
    </div>
  );
}
import fs from 'fs';
import path from 'path';
import matter from 'gray-matter';
import { MDXRemote } from 'next-mdx-remote/rsc';
import CodeBlock from '@/app/components/CodeBlock';
import Quiz from '@/app/components/Quiz';

const components = {
  CodeBlock,
  Quiz,
};

export async function generateStaticParams() {
  const files = fs.readdirSync(path.join(process.cwd(), 'content/lessons'));
  return files.map((filename) => ({
    slug: filename.replace(/\.mdx$/, ''),
  }));
}

async function getLesson(slug: string) {
  const fullPath = path.join(process.cwd(), 'content/lessons', `${slug}.mdx`);
  const fileContents = fs.readFileSync(fullPath, 'utf8');
  const { data, content } = matter(fileContents);
  return { frontmatter: data, content };
}

export default async function LessonPage({ params }: { params: { slug: string } }) {
  const { frontmatter, content } = await getLesson(params.slug);

  return (
    <article className="prose dark:prose-invert max-w-none">
      <h1 className="text-3xl font-bold mb-4">{frontmatter.title}</h1>
      <MDXRemote source={content} components={components} />
    </article>
  );
}